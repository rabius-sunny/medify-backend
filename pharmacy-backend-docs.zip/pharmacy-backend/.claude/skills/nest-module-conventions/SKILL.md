---
name: nest-module-conventions
description: File layout, guard order, validation, error mapping, pagination, and idempotency conventions for NestJS modules in the B2B pharmacy platform. Use when creating a new module, adding an endpoint or controller, writing a DTO or service, wiring guards, handling errors, or reviewing whether module code follows house structure. Consult before scaffolding, so structure is right the first time.
---

# NestJS Module Conventions

Twelve modules, hard boundaries. **A module owns its tables. Never query another module's tables directly** — go through its exported service. This is what keeps the monolith from turning into a ball of mud, and it is what makes a future extraction possible without making it necessary now.

## File layout

Every module follows the same shape:

```
src/modules/<name>/
├─ <name>.module.ts
├─ controllers/
│  ├─ <name>.app.controller.ts      # pharmacy-facing,  /app/*
│  └─ <name>.admin.controller.ts    # staff-facing,     /admin/*
├─ services/
│  └─ <name>.service.ts             # domain logic — no HTTP concepts
├─ repositories/
│  └─ <name>.repository.ts          # Drizzle queries only — no business rules
├─ dto/
│  └─ *.schema.ts                   # Zod schema + createZodDto in one file
├─ errors/
│  └─ <name>.errors.ts              # typed domain errors
└─ __tests__/
   └─ <name>.service.spec.ts        # unit tests only
```

**Separate controllers per audience.** One controller serving both `/app` and `/admin` is where tenant-scoping bugs are born — the guard set differs, so the controllers differ.

**Repositories hold queries, services hold rules.** A repository never decides anything; a service never writes SQL.

## Guard order

Applied in this sequence, always:

```ts
@Controller('app/orders')
@UseGuards(JwtAuthGuard, RolesGuard, AccountStatusGuard, PharmacyScopeGuard)
@Roles('PHARMACY_OWNER')
export class OrdersAppController {}
```

1. `JwtAuthGuard` — global, opt out with `@Public()`
2. `RolesGuard` — role membership
3. `AccountStatusGuard` — pharmacy must be `APPROVED` for commerce routes
4. `PharmacyScopeGuard` — the resource belongs to the caller's pharmacy

**Scoping is enforced in a guard, never in each service.** The one service that forgets is the one that leaks Pharmacy A's orders to Pharmacy B — and on a platform where competitors share the system, that is the incident that ends the contract.

**Cross-tenant access returns 404, not 403.** A 403 confirms the resource exists.

## Validation

One Zod schema drives the DTO type, runtime validation, and OpenAPI:

```ts
export const PlaceOrderSchema = z.object({
  paymentMethod: z.enum(['COD', 'DIGITAL']),
  items: z.array(z.object({
    productId: z.string().uuid(),
    qty: z.number().int().positive().max(10_000),
  })).min(1).max(200),
});
export class PlaceOrderDto extends createZodDto(PlaceOrderSchema) {}
```

Global `ZodValidationPipe`, `whitelist: true` — unknown fields are **rejected, not silently dropped**. Always bound array lengths and numeric ranges; an unbounded array is a denial-of-service vector.

**Never accept a price, total, or availability from the client.** Take IDs and quantities; compute everything else server-side.

## Errors

Typed domain errors, mapped centrally to RFC 7807 `problem+json`:

```ts
export class InsufficientStockError extends DomainError {
  readonly status = 409;
  readonly type = 'insufficient-stock';
  constructor(productId: string, available: number) {
    super(`Only ${available} units available`, { productId, available });
  }
}
```

Response shape:
```json
{
  "type": "https://api.example.com/errors/insufficient-stock",
  "title": "Insufficient stock",
  "status": 409,
  "detail": "Napa Extra 500mg — 12 units available, 50 requested",
  "requestId": "01J8X...",
  "context": { "productId": "...", "available": 12 }
}
```

Unexpected errors log the stack, report to Sentry, and return a generic 500 carrying the request ID. **Internals never reach the client.**

Status codes: `400` malformed · `401` unauthenticated · `403` wrong role · `404` missing *or cross-tenant* · `409` state conflict (stock, duplicate) · `422` business rule violation (minimums, MOQ).

## Pagination

**Keyset cursors everywhere. `OFFSET` is never acceptable on a growing table.**

```ts
WHERE (created_at, id) < (:cursorTs, :cursorId)
ORDER BY created_at DESC, id DESC
LIMIT :limit
```

Response: `{ items: [...], nextCursor: string | null }`. Default limit 20, cap 100.

## Idempotency

Required on every external write path — order placement, payment initiation, webhooks, import commit.

- Client sends `Idempotency-Key`; store `(pharmacy_id, key)`; a replay within 24h **returns the original response**, not a duplicate resource.
- Webhooks dedupe on `(provider, event_id)` with a unique constraint. Persist the raw payload **before** processing.

## Transactions

- One transaction per use case, opened in the service, never in a repository or controller.
- Queue jobs are scheduled via the **after-commit hook**, never inside the transaction.
- Keep transactions short. No HTTP calls, no PDF rendering, no file uploads inside one.

## Testing

**Unit tests only.** Pure logic: pricing, tier resolution, state transitions, validation schemas, courier status mapping. Mock the repository. Everything else is verified by curl against a running server, per `BUILD_PLAN.md`.

## Before finishing a module

- [ ] `pnpm typecheck` clean
- [ ] Separate app/admin controllers with correct guard stacks
- [ ] Zod schema on every input, arrays and numbers bounded
- [ ] Domain errors typed, mapped to the right status
- [ ] Keyset pagination on every list endpoint
- [ ] No cross-module table access
- [ ] New env vars in `.env.example` and the config schema
- [ ] Curl-verified end to end
