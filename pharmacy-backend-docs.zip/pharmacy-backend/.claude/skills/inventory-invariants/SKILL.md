---
name: inventory-invariants
description: Stock reservation, locking, and ledger rules for the B2B pharmacy platform. Use whenever writing or reviewing code that reads or changes stock — order placement, order approval or rejection, order cancellation, confirmation, stock receiving, stock adjustments, reservation expiry, or anything touching stock_on_hand, stock_reserved, stock_reservations, or stock_movements. This is the highest-risk area of the system; consult before writing, not after a bug appears.
---

# Inventory Invariants

All stock reads and mutations go through **`InventoryService`**. Nothing else touches `stock_on_hand` or `stock_reserved` — not a controller, not a report, not a migration script.

## The model

| Column | Meaning |
| :--- | :--- |
| `products.stock_on_hand` | Physical units in the warehouse. Equals `SUM(stock_movements.qty_delta)`, always. |
| `products.stock_reserved` | Sum of `ACTIVE` reservations. |
| **`available = stock_on_hand − stock_reserved`** | What a pharmacy may order. |

Both columns are **derived caches maintained inside the same transaction** as the ledger row or reservation that changes them. `stock_movements` is the record of truth; the columns exist so reads are fast.

## Reservation lifecycle

```
order placed  ──► ACTIVE (expires_at = now + 3h)
                    │
      ┌─────────────┼──────────────┬───────────────────┐
      │             │              │                   │
 order rejected  cancelled    3h elapsed          order confirmed
      │             │              │                   │
      ▼             ▼              ▼                   ▼
   RELEASED     RELEASED       RELEASED            CONSUMED
                                                (ledger ALLOCATION,
                                                 stock_on_hand −)
```

**Reservations are consumed at confirmation, never at approval.** For a digital-payment order, approval moves it to `AWAITING_PAYMENT` and the reservation TTL is *extended* to the payment window. If the pharmacy never pays, the stock returns to the pool automatically. Consuming at approval would strand stock on every unpaid order.

## The locking transaction — get this exactly right

```ts
// 1. Deterministic lock order. NON-NEGOTIABLE.
const productIds = [...new Set(items.map(i => i.productId))].sort();
const locked = await tx.execute(sql`
  SELECT id, stock_on_hand, stock_reserved, base_price, is_active
  FROM products
  WHERE id = ANY(${productIds})
  ORDER BY id
  FOR UPDATE
`);

// 2. Validate against the LOCKED rows, not a prior read
for (const item of items) {
  const p = locked.find(r => r.id === item.productId);
  if (!p?.is_active) throw new ProductUnavailableError(item.productId);
  const available = p.stock_on_hand - p.stock_reserved;
  if (available < item.qty) {
    throw new InsufficientStockError(item.productId, available);
  }
}

// 3. Insert reservations + increment stock_reserved, same transaction
// 4. Schedule the expiry job AFTER COMMIT
```

**Why `ORDER BY id` matters:** two pharmacies ordering products A and B in opposite orders will deadlock intermittently without it. It will pass every test you write and fail in production under real concurrency. Never omit it.

**Why validate against locked rows:** anything read before the lock is stale by the time you act on it. A pre-read availability check is decoration, not a guarantee.

## Idempotency

`release()` and `consume()` must both be **no-ops when the reservation is not `ACTIVE`**. Running either twice is harmless and expected — expiry jobs retry, webhooks redeliver, admins double-click.

```ts
async release(reservationId, reason) {
  return this.db.transaction(async (tx) => {
    const r = await tx.select().from(reservations)
      .where(eq(reservations.id, reservationId)).for('update');
    if (r.status !== 'ACTIVE') return;          // already handled — done
    await tx.update(reservations).set({ status: 'RELEASED', ... });
    await tx.execute(sql`
      UPDATE products SET stock_reserved = stock_reserved - ${r.qty}
      WHERE id = ${r.productId}
    `);
  });
}
```

## Expiry — two mechanisms, deliberately redundant

1. **Primary:** a BullMQ delayed job per order, `jobId = expire:{orderId}` (deterministic, so a retried enqueue cannot create a duplicate), scheduled at `expires_at`.
2. **Safety net:** a cron sweep every 5 minutes:
   ```sql
   SELECT id FROM stock_reservations
   WHERE status = 'ACTIVE' AND expires_at < now()
   FOR UPDATE SKIP LOCKED
   LIMIT 100
   ```

`SKIP LOCKED` lets multiple workers sweep concurrently without contention. The sweep exists because a Redis restart or failover loses delayed jobs, and a lost job means stock stranded forever with no error anywhere.

Expiry is 3 hours of **plain clock time** — an order placed at 23:00 expires at 02:00 unreviewed. That is accepted, and mitigated by auto-cancelling with a push notification carrying the original lines for one-tap reorder.

## Queue jobs and transactions

**Never enqueue inside a transaction.** Use the after-commit hook:

```ts
this.afterCommit(() => this.queue.add('expire', { orderId }, { delay, jobId }));
```

A job scheduled inside a transaction that then rolls back references an order that does not exist. The worker fires, finds nothing, and either crashes or silently does nothing — both are hard to trace back to this cause.

## Ledger rules

- `stock_movements` is **append-only**. Never update, never delete. Corrections are new rows.
- Types: `RECEIPT` (stock arrived), `ADJUSTMENT` (correction, **reason mandatory**), `ALLOCATION` (order confirmed, negative delta), `RETURN` (enum reserved, no flow at launch).
- Every row records `actor_id`, `reason`, and `balance_after`.
- Invariant, assertable at any time: `products.stock_on_hand = SUM(stock_movements.qty_delta)` for that product.

## Verification before finishing any inventory change

- [ ] `FOR UPDATE ... ORDER BY id` present on every multi-product lock
- [ ] Availability computed from locked rows inside the transaction
- [ ] `release`/`consume` are no-ops on non-`ACTIVE` reservations
- [ ] No queue job enqueued inside a transaction
- [ ] Stock availability is **not** cached anywhere
- [ ] Concurrency check run: N parallel orders against N/2 units → exactly half succeed, half return 409, zero oversell
- [ ] `stock_on_hand` reconciles against the ledger sum
