---
name: pricing-rules
description: Money calculation rules for the B2B pharmacy platform — price tier resolution, VAT, delivery charge, minimum order enforcement, and partial-approval recalculation. Use whenever writing or reviewing code that computes a price, a total, a tax, a delivery charge, or a discount; whenever building cart preview, order placement, order approval, invoices, or reports; and whenever a number shown to a pharmacy or printed on an invoice is produced. Do not calculate money without consulting this.
---

# Pricing Rules

All money arithmetic in this system lives in **`PricingService`**. If a calculation appears in a controller, a report query, a PDF template, or a test fixture, that is a bug — extract it.

## Calculation order

Exactly this sequence. Do not reorder, do not fold steps together.

```
line_total       = tier_unit_price × qty          (per approved line)
subtotal         = Σ line_total
discount         = order-level discount, if any
taxable_base     = subtotal − discount
vat              = round(taxable_base × vat_rate, 2)
delivery_charge  = zone.charge                     (snapshotted at placement)
vat_on_delivery  = vat_applies_to_delivery
                     ? round(delivery_charge × vat_rate, 2)
                     : 0
grand_total      = taxable_base + vat + delivery_charge + vat_on_delivery
```

**Round once per component, at the end.** Rounding each line and summing produces totals that disagree with the invoice by a few poisha — small enough to ship, large enough to become an accounting dispute.

**Use Postgres `numeric` arithmetic. Never JavaScript floats.** `0.1 + 0.2` is not `0.3`, and an invoice is a financial document.

## Price tier resolution

`product_price_tiers` holds `(product_id, min_qty, unit_price)`.

**Rule: the highest `min_qty` that is ≤ the ordered quantity wins. If no tier qualifies, fall back to `products.base_price`.**

```ts
resolveTier(product, qty) {
  const tier = product.priceTiers
    .filter(t => t.minQty <= qty)
    .sort((a, b) => b.minQty - a.minQty)[0];
  return tier?.unitPrice ?? product.basePrice;
}
```

Boundary cases that must be covered by unit tests:
- qty below the lowest tier → `base_price`
- qty exactly equal to a tier's `min_qty` → that tier applies
- qty above the highest tier → highest tier applies
- product with a single tier
- product with no tiers at all

## Snapshotting — the rule that prevents silent corruption

At order placement, snapshot onto the order and its lines:

| Snapshotted | Where |
| :--- | :--- |
| `unit_price` (tier-resolved), `product_name`, `pack_size`, `manufacturer_id` | `order_items` |
| `vat_rate`, `vat_applies_to_delivery`, `delivery_zone_id`, `delivery_zone_name`, `delivery_charge` | `orders` |

**Never join to `products`, `product_price_tiers`, `platform_settings`, or `delivery_zones` when rendering a historical order or invoice.** Changing the VAT rate tomorrow must not alter an order placed today, and must not alter an invoice already issued. Reading a live rate for a past order is the single most damaging mistake available in this module.

## Partial approval recalculation

When an admin reduces or removes lines:

1. **Re-resolve the price tier on every reduced line.** Dropping 100 units to 40 may cross a tier boundary. Keeping the 100-unit price is overcharging; keeping it silently is worse.
2. **Recalculate VAT** on the new taxable base.
3. **Do not change the delivery charge.** The van drives the same distance for 8 items as for 10.
4. **If every line is removed, reject the order.** Never approve an order whose total is delivery charge alone.
5. Write both `placed_*` and `approved_*` totals so the pharmacy can be shown exactly what changed.

## Minimum order enforcement

Two independent rules, checked at cart preview **and** re-validated inside the placement transaction. A client-side check is a convenience, never a control.

| Rule | Source | Applies to |
| :--- | :--- | :--- |
| Minimum order value | `platform_settings.min_order_value` | `subtotal` — **goods only**, before VAT and delivery, so the charge can't be used to reach the minimum |
| Minimum quantity | `products.min_order_qty` | each line |
| Order multiple | `products.order_multiple` | each line — qty must be an exact multiple |

Violations return `422` with a **per-line breakdown**, so the app can highlight offending items instead of showing one unhelpful banner.

**Admin partial approval is exempt from all minimums.** If reducing a line takes it below its MOQ, or drops the order under the minimum value, the approval still stands. Minimums shape what pharmacies *submit*; they must not override staff judgement about what to ship. This asymmetry is deliberate — do not "fix" it.

## Delivery zones

- A pharmacy's district maps to exactly one active zone. Overlapping district assignments are rejected at configuration time.
- An **unmapped district falls back to `platform_settings.default_delivery_charge` and raises an admin warning** — it must never block checkout. A pharmacy cannot order because your zone table is incomplete is an unacceptable failure mode.
- The resolved zone and its charge are snapshotted on the order.

## Checklist before finishing any money-touching change

- [ ] All arithmetic inside `PricingService` — grep the diff to confirm
- [ ] `numeric` / decimal types throughout, no floats
- [ ] Rates read from the order's snapshot, not from live settings
- [ ] Unit tests cover tier boundaries and the VAT-on-delivery flag both ways
- [ ] Totals reconcile to the poisha against the sum of lines
