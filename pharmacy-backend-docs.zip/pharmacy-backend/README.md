# B2B Pharmacy Platform — Backend Docs Bundle

Drop these at the root of the backend repository.

```
CLAUDE.md                          # agent working rules — read first
ARCHITECTURE.md                    # system design, data model, decisions
BUILD_PLAN.md                      # 17 sequential phases, curl-verified
.claude/skills/
├── pricing-rules/                 # money: tiers, VAT, delivery, minimums
├── inventory-invariants/          # stock: reservations, locking, ledger
└── nest-module-conventions/       # module layout, guards, errors, pagination
```

## Setup

```bash
cp -r pharmacy-backend/. /path/to/your-repo/
cd /path/to/your-repo
claude
```

Skills in `.claude/skills/` load automatically when relevant — no install step, no marketplace. Commit them; they are project knowledge, not personal config.

## Reading order

1. **`CLAUDE.md`** — workflow rules and the ten non-negotiable invariants
2. **`ARCHITECTURE.md`** — why the system is shaped this way; §0 lists every confirmed decision
3. **`BUILD_PLAN.md`** — start at Phase 0, work in order

## The three risky phases

Phases **8 (reservations)**, **9 (order placement)**, and **10 (approval and confirmation)** carry the real complexity and are strictly sequential. Reservations must be provably correct before orders are built on them. If schedule pressure appears, cut Phase 15 scope — never compress Phase 8.

Phase 8's acceptance test is the one that matters: 20 parallel orders against 10 units must produce exactly 10 successes and 10 conflicts. Zero oversell.

## Verifying the skills load

In Claude Code, run `/context` to confirm the three skills are registered. If a skill isn't triggering when it should, its `description` frontmatter is the thing to sharpen — that field is what the agent matches against, not the body.
